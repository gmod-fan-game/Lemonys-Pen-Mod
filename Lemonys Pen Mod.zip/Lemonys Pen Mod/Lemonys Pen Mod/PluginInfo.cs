﻿namespace Lemonys_Pen_Mod
{
    /// <summary>
    /// This class is used to provide information about your mod to BepInEx.
    /// </summary>
    internal class PluginInfo
    {
        public const string GUID = "com.lemony.gorillatag.lemonys pen mod";
        public const string Name = "Lemonys_Pen_Mod";
        public const string Version = "1.0.0";
    }
}
